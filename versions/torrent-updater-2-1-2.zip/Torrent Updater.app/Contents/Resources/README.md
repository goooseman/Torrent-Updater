# Torrent Updater  
  
An Open Source OS X program for looking for torrent updates on your favourite BitTorrent trackers.  
  

Ideal for keeping track of TV shows' new series.  
  

**Features**:  
* Notifying user through Notification Center when torrent has been updated.
* Autodownloading updated torrents to choosen folder.
* RuTracker.org, Kinozal.tv and New-RuTor.org are supported at the moment (Yes, there are no non-russian trackers, <br> but you can <a href="/en/contact.html">write me down</a> and I'll add new trackers).   
  

You can easily add new tracker's support to this program by editting trackers.plist file. Don't forget to commit ;)  
  

[Official site](http://torrent-updater.goooseman.ru)